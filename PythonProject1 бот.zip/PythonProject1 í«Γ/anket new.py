import asyncio
import logging

from aiogram import Bot, Dispatcher, Router, F
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    Message,
    CallbackQuery,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

# ==== НАСТРОЙКИ ====
BOT_TOKEN = "8731768429:AAEMx5Orm2Zc_kI1GaKYrVqRMP9s70KQyBc"
ADMIN_ID = 8900763872  # <-- замени на свой Telegram ID (узнать можно у @userinfobot)

logging.basicConfig(level=logging.INFO)

router = Router()

# ==== ТЕКСТЫ И ЦЕНЫ ====
START_TEXT = (
    "хайй! я вейвер (бот)\n\n"
    "я помогу тебе с любым вопросом! выбери одну из категорий ниже:"
)

TYPE_NO_3D = "Позинг без 3D объекта (15 рублей / 20 робуксов)"
TYPE_WITH_3D = "Позинг с 3D объектом (20 рублей / 25 робуксов)"

# ==== ХРАНИЛИЩА В ПАМЯТИ ====
ORDERS: dict[int, dict] = {}
ORDER_COUNTER = {"value": 0}
ACTIVE_CHATS: dict[int, int] = {}  # user_id <-> admin_id, в обе стороны


def next_order_id() -> int:
    ORDER_COUNTER["value"] += 1
    return ORDER_COUNTER["value"]


# ==== СОСТОЯНИЯ ====
class OrderForm(StatesGroup):
    waiting_preferences = State()  # страница 2
    waiting_description = State()  # страница 3
    confirm = State()              # страница 4


class AdminForm(StatesGroup):
    waiting_time = State()
    waiting_reason = State()


# ==== КЛАВИАТУРЫ ====
def main_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Соцсети", callback_data="social")],
            [InlineKeyboardButton(text="Связь с администрацией", callback_data="admin_contact")],
            [InlineKeyboardButton(text="Заказать позинг", callback_data="posing")],
        ]
    )


def nav_row(page: int) -> list[InlineKeyboardButton]:
    return [
        InlineKeyboardButton(text="⬅️ Назад", callback_data=f"nav:back:{page}"),
        InlineKeyboardButton(text="❌ Отмена", callback_data=f"nav:cancel:{page}"),
    ]


def page1_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=TYPE_NO_3D, callback_data="type:no3d")],
            [InlineKeyboardButton(text=TYPE_WITH_3D, callback_data="type:3d")],
            nav_row(1),
        ]
    )


def page2_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[nav_row(2)])


def page3_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[nav_row(3)])


def page4_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="✅ Отправить анкету", callback_data="form:send")],
            [InlineKeyboardButton(text="❌ Отмена", callback_data="nav:cancel:4")],
        ]
    )


def admin_decision_kb(order_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Принять", callback_data=f"admin:accept:{order_id}"),
                InlineKeyboardButton(text="❌ Отклонить", callback_data=f"admin:reject:{order_id}"),
            ]
        ]
    )


def start_chat_kb(order_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Начать чат через бота", callback_data=f"admin:chat:{order_id}")]
        ]
    )


def active_chat_kb(order_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="❌ Завершить чат", callback_data=f"admin:endchat:{order_id}")]
        ]
    )


# ==== ТЕКСТЫ СТРАНИЦ ====
PAGE1_TEXT = "1/4 какой тип позинга хотите? (оплата после получения работы)"
PAGE2_TEXT = (
    "2/4 напишите особые предпочтения к позингу за доп. оплату, "
    "если предпочтений нету отправьте точку (пример: позинг на двух человек)"
)
PAGE3_TEXT = (
    "3/4 какой позинг хотите? если вы хотите чтобы я придумал все сам пишите точку "
    "(можно скинуть референс или описать словами)"
)


def page4_text(order: dict) -> str:
    if order.get("description_photo"):
        description_line = "фото (см. выше)"
        if order.get("description_text"):
            description_line += f", комментарий: {order['description_text']}"
    else:
        description_line = order.get("description_text", "-")

    return (
        "4/4 правильно ли вы все указали?\n\n"
        f"1. тип позинга: {order.get('type_text', '-')}\n\n"
        f"2. особые предпочтения: {order.get('preferences', '-')}\n\n"
        f"3. какой позинг хотите получить: {description_line}\n\n"
        "‼️сумма будет озвучена после принятия анкеты‼️"
    )


def admin_order_text(order_id: int, order: dict) -> str:
    if order.get("description_photo"):
        description_line = "фото (см. выше)"
        if order.get("description_text"):
            description_line += f", комментарий: {order['description_text']}"
    else:
        description_line = order.get("description_text", "-")

    username = order.get("username")
    user_line = f"@{username}" if username else f"id: {order.get('user_id')}"

    return (
        f"📋 Новая анкета на позинг #{order_id}\n\n"
        f"1. Тип позинга: {order.get('type_text', '-')}\n\n"
        f"2. Особые предпочтения: {order.get('preferences', '-')}\n\n"
        f"3. Какой позинг хотят получить: {description_line}\n\n"
        f"Заказчик: {user_line}"
    )


# ==== ГЛАВНОЕ МЕНЮ ====
@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(START_TEXT, reply_markup=main_kb())


@router.callback_query(F.data == "social")
async def handle_social(callback: CallbackQuery):
    await callback.message.answer("Здесь будут ссылки на соцсети.")
    await callback.answer()


@router.callback_query(F.data == "admin_contact")
async def handle_admin_contact(callback: CallbackQuery):
    await callback.message.answer("Здесь будет контакт администрации.")
    await callback.answer()


# ==== СТРАНИЦА 1 ====
@router.callback_query(F.data == "posing")
async def start_order(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await state.update_data(order={})
    await callback.message.edit_text(PAGE1_TEXT, reply_markup=page1_kb())
    await callback.answer()


@router.callback_query(F.data.startswith("type:"))
async def choose_type(callback: CallbackQuery, state: FSMContext):
    type_key = callback.data.split(":")[1]
    type_text = TYPE_NO_3D if type_key == "no3d" else TYPE_WITH_3D

    data = await state.get_data()
    order = data.get("order", {})
    order["type_text"] = type_text
    await state.update_data(order=order)

    await state.set_state(OrderForm.waiting_preferences)
    await callback.message.edit_text(PAGE2_TEXT, reply_markup=page2_kb())
    await callback.answer()


# ==== СТРАНИЦА 2 ====
@router.message(OrderForm.waiting_preferences)
async def get_preferences(message: Message, state: FSMContext):
    data = await state.get_data()
    order = data.get("order", {})
    order["preferences"] = message.text or "."
    await state.update_data(order=order)

    await state.set_state(OrderForm.waiting_description)
    await message.answer(PAGE3_TEXT, reply_markup=page3_kb())


# ==== СТРАНИЦА 3 ====
@router.message(OrderForm.waiting_description)
async def get_description(message: Message, state: FSMContext):
    data = await state.get_data()
    order = data.get("order", {})

    if message.photo:
        order["description_photo"] = message.photo[-1].file_id
        order["description_text"] = message.caption or ""
    else:
        order["description_photo"] = None
        order["description_text"] = message.text or "."

    await state.update_data(order=order)
    await state.set_state(OrderForm.confirm)

    text = page4_text(order)
    if order.get("description_photo"):
        await message.answer_photo(order["description_photo"], caption=text, reply_markup=page4_kb())
    else:
        await message.answer(text, reply_markup=page4_kb())


# ==== НАВИГАЦИЯ (НАЗАД / ОТМЕНА) ====
@router.callback_query(F.data.startswith("nav:"))
async def navigate(callback: CallbackQuery, state: FSMContext):
    _, action, page_str = callback.data.split(":")
    page = int(page_str)

    if action == "cancel":
        await state.clear()
        await callback.message.edit_text(START_TEXT, reply_markup=main_kb())
        await callback.answer()
        return

    # action == "back"
    if page == 1:
        await state.clear()
        await callback.message.edit_text(START_TEXT, reply_markup=main_kb())
    elif page == 2:
        await state.set_state(None)
        await callback.message.edit_text(PAGE1_TEXT, reply_markup=page1_kb())
    elif page == 3:
        await state.set_state(OrderForm.waiting_preferences)
        await callback.message.edit_text(PAGE2_TEXT, reply_markup=page2_kb())

    await callback.answer()


# ==== СТРАНИЦА 4: ОТПРАВКА АНКЕТЫ ====
@router.callback_query(F.data == "form:send")
async def send_form(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    order = data.get("order", {})

    order_id = next_order_id()
    order["user_id"] = callback.from_user.id
    order["username"] = callback.from_user.username
    ORDERS[order_id] = order

    await state.clear()

    if order.get("description_photo"):
        await callback.message.edit_caption(caption="Ваш заказ на рассмотрении!")
    else:
        await callback.message.edit_text("Ваш заказ на рассмотрении!")

    summary = admin_order_text(order_id, order)
    kb = admin_decision_kb(order_id)
    if order.get("description_photo"):
        await callback.bot.send_photo(ADMIN_ID, order["description_photo"], caption=summary, reply_markup=kb)
    else:
        await callback.bot.send_message(ADMIN_ID, summary, reply_markup=kb)

    await callback.answer()


# ==== АДМИН: ПРИНЯТЬ / ОТКЛОНИТЬ ====
@router.callback_query(F.data.startswith("admin:accept:"))
async def admin_accept(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id != ADMIN_ID:
        await callback.answer()
        return

    order_id = int(callback.data.split(":")[2])
    await state.update_data(pending_order_id=order_id)
    await state.set_state(AdminForm.waiting_time)
    await callback.message.answer("Через какое время будет готов позинг? Напишите срок (например: 2 дня).")
    await callback.answer()


@router.callback_query(F.data.startswith("admin:reject:"))
async def admin_reject(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id != ADMIN_ID:
        await callback.answer()
        return

    order_id = int(callback.data.split(":")[2])
    await state.update_data(pending_order_id=order_id)
    await state.set_state(AdminForm.waiting_reason)
    await callback.message.answer("Укажите причину отказа:")
    await callback.answer()


@router.message(AdminForm.waiting_time)
async def admin_set_time(message: Message, state: FSMContext):
    data = await state.get_data()
    order_id = data.get("pending_order_id")
    order = ORDERS.get(order_id)
    await state.clear()

    if not order:
        await message.answer("Заказ не найден.")
        return

    order["status"] = "accepted"
    order["deadline"] = message.text

    await message.bot.send_message(
        order["user_id"],
        f"Ваш заказ одобрен! Время выполнения: {message.text}",
    )
    await message.answer("Заказчик уведомлён.", reply_markup=start_chat_kb(order_id))


@router.message(AdminForm.waiting_reason)
async def admin_set_reason(message: Message, state: FSMContext):
    data = await state.get_data()
    order_id = data.get("pending_order_id")
    order = ORDERS.get(order_id)
    await state.clear()

    if not order:
        await message.answer("Заказ не найден.")
        return

    order["status"] = "rejected"

    await message.bot.send_message(
        order["user_id"],
        f"к сожалению ваш заказ отменили(( причина: {message.text}",
    )
    await message.answer("Заказчику отправлено уведомление об отказе.")


# ==== АДМИН: НАЧАТЬ ЧАТ ЧЕРЕЗ БОТА ====
@router.callback_query(F.data.startswith("admin:chat:"))
async def admin_start_chat(callback: CallbackQuery):
    if callback.from_user.id != ADMIN_ID:
        await callback.answer()
        return

    order_id = int(callback.data.split(":")[2])
    order = ORDERS.get(order_id)
    if not order:
        await callback.answer("Заказ не найден", show_alert=True)
        return

    user_id = order["user_id"]
    ACTIVE_CHATS[ADMIN_ID] = user_id
    ACTIVE_CHATS[user_id] = ADMIN_ID

    await callback.message.answer(
        "Чат с заказчиком начат. Все ваши сообщения будут пересылаться ему.",
        reply_markup=active_chat_kb(order_id),
    )
    await callback.bot.send_message(user_id, "С вами связался продавец! Теперь можете писать прямо сюда.")
    await callback.answer()


@router.callback_query(F.data.startswith("admin:endchat:"))
async def admin_end_chat(callback: CallbackQuery):
    if callback.from_user.id != ADMIN_ID:
        await callback.answer()
        return

    order_id = int(callback.data.split(":")[2])
    order = ORDERS.get(order_id)

    user_id = order["user_id"] if order else ACTIVE_CHATS.get(ADMIN_ID)

    if user_id is not None:
        ACTIVE_CHATS.pop(ADMIN_ID, None)
        ACTIVE_CHATS.pop(user_id, None)
        await callback.bot.send_message(user_id, "Чат с продавцом завершён.")

    await callback.message.edit_text("Чат завершён. Пересылка сообщений отключена.")
    await callback.answer()


# ==== ПЕРЕСЫЛКА СООБЩЕНИЙ В АКТИВНОМ ЧАТЕ (должен быть последним хендлером) ====
@router.message()
async def relay_chat(message: Message):
    partner_id = ACTIVE_CHATS.get(message.from_user.id)
    if not partner_id:
        return
    await message.bot.copy_message(
        chat_id=partner_id,
        from_chat_id=message.chat.id,
        message_id=message.message_id,
    )


async def main():
    bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(router)

    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
