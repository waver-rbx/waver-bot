import asyncio
import logging

from aiogram import Bot, Dispatcher, Router
from aiogram.filters import CommandStart
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

# Вставь сюда свой токен, полученный от @BotFather
BOT_TOKEN = "8731768429:AAEMx5Orm2Zc_kI1GaKYrVqRMP9s70KQyBc"

logging.basicConfig(level=logging.INFO)

router = Router()


def get_start_keyboard() -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Соцсети", callback_data="social")],
            [InlineKeyboardButton(text="Связь с администрацией", callback_data="admin")],
            [InlineKeyboardButton(text="Заказать позинг", callback_data="posing")],
        ]
    )
    return keyboard


@router.message(CommandStart())
async def cmd_start(message: Message):
    text = (
        "хайй! я вейвер (бот)\n\n"
        "я помогу тебе с любым вопросом! выбери одну из категорий ниже:"
    )
    await message.answer(text, reply_markup=get_start_keyboard())


# Обработчики нажатий на кнопки — сюда добавишь свою логику под каждую категорию
@router.callback_query(lambda c: c.data == "social")
async def handle_social(callback):
    await callback.message.answer("Здесь будут ссылки на соцсети.")
    await callback.answer()


@router.callback_query(lambda c: c.data == "admin")
async def handle_admin(callback):
    await callback.message.answer("Здесь будет контакт администрации.")
    await callback.answer()


@router.callback_query(lambda c: c.data == "posing")
async def handle_posing(callback):
    await callback.message.answer("Здесь будет форма заказа позинга.")
    await callback.answer()


async def main():
    bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.include_router(router)

    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
